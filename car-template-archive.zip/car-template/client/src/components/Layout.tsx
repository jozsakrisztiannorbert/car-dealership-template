import { Link, useLocation } from "wouter";
import { dealerConfig } from "@/config/dealer";
import { Phone, Menu, X, Car } from "lucide-react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export function Navbar() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/inventory", label: "Inventory" },
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
  ];

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
        scrolled
          ? "bg-background/95 backdrop-blur-md border-border py-2 shadow-sm"
          : "bg-transparent border-transparent py-4"
      )}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2 group">
            <div className="bg-primary text-primary-foreground p-2 rounded-lg group-hover:bg-accent transition-colors">
              <Car size={24} />
            </div>
            <span className="font-heading font-bold text-xl tracking-tight text-foreground">
              {dealerConfig.dealerName}
            </span>
          </a>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <a
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location === link.href
                    ? "text-primary font-semibold"
                    : "text-muted-foreground"
                )}
              >
                {link.label}
              </a>
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <a href={`tel:${dealerConfig.phone}`} className="text-sm font-semibold text-foreground hover:text-primary transition-colors">
            {dealerConfig.phone}
          </a>
          <Button className="bg-primary hover:bg-primary/90 text-white rounded-full px-6">
            Book Appointment
          </Button>
        </div>

        {/* Mobile Nav */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu size={24} />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[400px]">
            <div className="flex flex-col gap-8 mt-10">
              <nav className="flex flex-col gap-4">
                {navLinks.map((link) => (
                  <Link key={link.href} href={link.href}>
                    <a
                      className={cn(
                        "text-lg font-medium transition-colors hover:text-primary",
                        location === link.href
                          ? "text-primary font-semibold"
                          : "text-muted-foreground"
                      )}
                    >
                      {link.label}
                    </a>
                  </Link>
                ))}
              </nav>
              <div className="flex flex-col gap-4">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Book Appointment
                </Button>
                <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                    <p>Call us: {dealerConfig.phone}</p>
                    <p>Email: {dealerConfig.email}</p>
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-slate-950 text-slate-200 py-16">
      <div className="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="space-y-4">
           <div className="flex items-center gap-2">
            <div className="bg-white text-slate-950 p-2 rounded-lg">
              <Car size={24} />
            </div>
            <span className="font-heading font-bold text-xl tracking-tight text-white">
              {dealerConfig.dealerName}
            </span>
          </div>
          <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
            Premium pre-owned luxury vehicles. We provide a transparent, high-end buying experience for the discerning driver.
          </p>
        </div>

        <div>
          <h4 className="font-heading font-bold text-white mb-6">Explore</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li><Link href="/inventory"><a className="hover:text-white transition-colors">Inventory</a></Link></li>
            <li><Link href="/about"><a className="hover:text-white transition-colors">About Us</a></Link></li>
            <li><Link href="/contact"><a className="hover:text-white transition-colors">Contact</a></Link></li>
            <li><Link href="/privacy"><a className="hover:text-white transition-colors">Privacy Policy</a></Link></li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-bold text-white mb-6">Contact</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li>{dealerConfig.address}</li>
            <li>{dealerConfig.phone}</li>
            <li>{dealerConfig.email}</li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-bold text-white mb-6">Hours</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li className="flex justify-between"><span>Mon - Fri</span> <span>{dealerConfig.hours.mon_fri}</span></li>
            <li className="flex justify-between"><span>Saturday</span> <span>{dealerConfig.hours.sat}</span></li>
            <li className="flex justify-between"><span>Sunday</span> <span>{dealerConfig.hours.sun}</span></li>
          </ul>
        </div>
      </div>
      <div className="container mx-auto px-4 mt-16 pt-8 border-t border-slate-800 text-center text-xs text-slate-500">
        © {new Date().getFullYear()} {dealerConfig.dealerName}. All rights reserved.
      </div>
    </footer>
  );
}

export function MobileBottomBar() {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 bg-background border-t border-border p-4 flex gap-4 z-50 safe-area-pb">
        <Button className="flex-1 bg-primary hover:bg-primary/90" asChild>
            <a href={`tel:${dealerConfig.phone}`}>Call Us</a>
        </Button>
        <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white" asChild>
            <a href={`https://wa.me/${dealerConfig.whatsapp.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer">WhatsApp</a>
        </Button>
    </div>
  );
}
