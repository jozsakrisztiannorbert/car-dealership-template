import { Navbar, Footer, MobileBottomBar } from "@/components/Layout";
import { dealerConfig } from "@/config/dealer";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-grow pt-24 pb-20 container mx-auto px-4">
        
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-6">Our Story</h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Serving the {dealerConfig.city} community with integrity and excellence for over 20 years.
            </p>
          </div>

          <div className="bg-background rounded-2xl shadow-sm border border-border overflow-hidden mb-16">
            <div className="aspect-[21/9] bg-slate-200">
              <img src="/images/hero-bg.png" alt="Dealership" className="w-full h-full object-cover" />
            </div>
            <div className="p-8 md:p-12">
              <h2 className="text-2xl font-heading font-bold mb-4">A Legacy of Luxury</h2>
              <div className="prose prose-slate max-w-none text-muted-foreground">
                <p className="mb-4">
                  Founded in 2004, {dealerConfig.dealerName} began with a simple mission: to provide a car buying experience that is as premium as the vehicles we sell. We believe that buying a luxury car should be an exciting, transparent, and personalized journey.
                </p>
                <p className="mb-4">
                  Our curated inventory features only the finest pre-owned vehicles, each hand-selected for its quality, history, and condition. We specialize in European luxury brands including Porsche, Mercedes-Benz, BMW, and Audi, as well as select exotics.
                </p>
                <p>
                  At {dealerConfig.dealerName}, we don't just sell cars; we build long-lasting relationships. Our dedicated team of automotive enthusiasts is here to guide you every step of the way, from finding your dream car to securing the best financing options.
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-background p-8 rounded-xl border border-border shadow-sm">
              <h3 className="text-xl font-heading font-bold mb-4 flex items-center gap-2">
                <MapPin className="text-primary" /> Visit Showroom
              </h3>
              <p className="text-muted-foreground mb-4">{dealerConfig.address}</p>
              <div className="aspect-video bg-slate-100 rounded-lg flex items-center justify-center text-muted-foreground text-sm">
                Map Embed Placeholder
              </div>
            </div>

            <div className="bg-background p-8 rounded-xl border border-border shadow-sm">
               <h3 className="text-xl font-heading font-bold mb-4 flex items-center gap-2">
                <Clock className="text-primary" /> Opening Hours
              </h3>
              <div className="space-y-3">
                 <div className="flex justify-between border-b border-border/50 pb-2">
                   <span className="text-muted-foreground">Monday - Friday</span>
                   <span className="font-medium">{dealerConfig.hours.mon_fri}</span>
                 </div>
                 <div className="flex justify-between border-b border-border/50 pb-2">
                   <span className="text-muted-foreground">Saturday</span>
                   <span className="font-medium">{dealerConfig.hours.sat}</span>
                 </div>
                 <div className="flex justify-between pb-2">
                   <span className="text-muted-foreground">Sunday</span>
                   <span className="font-medium text-destructive">{dealerConfig.hours.sun}</span>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
