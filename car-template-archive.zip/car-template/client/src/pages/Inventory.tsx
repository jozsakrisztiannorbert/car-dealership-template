import { Navbar, Footer, MobileBottomBar } from "@/components/Layout";
import { mockVehicles, MockVehicle } from "@/lib/mockData";
import { VehicleCard } from "@/components/VehicleCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useState, useMemo } from "react";
import { Filter, X } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

export default function Inventory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedMake, setSelectedMake] = useState<string>("all");
  const [priceRange, setPriceRange] = useState([0, 200000]);

  // Derive unique makes
  const makes = useMemo(() => {
    const uniqueMakes = new Set(mockVehicles.map((v) => v.make));
    return Array.from(uniqueMakes).sort();
  }, []);

  // Filter Logic
  const filteredVehicles = mockVehicles.filter((vehicle) => {
    const matchesSearch = 
      vehicle.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMake = selectedMake === "all" || vehicle.make === selectedMake;
    const matchesPrice = vehicle.price >= priceRange[0] && vehicle.price <= priceRange[1];

    return matchesSearch && matchesMake && matchesPrice;
  });

  const FilterContent = () => (
    <div className="space-y-8">
      <div className="space-y-3">
        <Label>Search</Label>
        <Input 
          placeholder="Search make or model..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="space-y-3">
        <Label>Make</Label>
        <Select value={selectedMake} onValueChange={setSelectedMake}>
          <SelectTrigger>
            <SelectValue placeholder="All Makes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Makes</SelectItem>
            {makes.map(make => (
              <SelectItem key={make} value={make}>{make}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
           <Label>Price Range</Label>
           <span className="text-xs text-muted-foreground">${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}</span>
        </div>
        <Slider 
          value={priceRange} 
          min={0} 
          max={200000} 
          step={5000} 
          onValueChange={setPriceRange} 
        />
      </div>

      <Button 
        variant="outline" 
        className="w-full"
        onClick={() => {
          setSearchTerm("");
          setSelectedMake("all");
          setPriceRange([0, 200000]);
        }}
      >
        Reset Filters
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      <main className="flex-grow pt-24 pb-20 container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-8 items-start">
            
          {/* Desktop Sidebar */}
          <aside className="hidden md:block w-64 shrink-0 bg-background border border-border p-6 rounded-xl sticky top-24 shadow-sm">
            <h3 className="font-heading font-bold text-lg mb-6 flex items-center gap-2">
              <Filter size={18} /> Filters
            </h3>
            <FilterContent />
          </aside>

          {/* Mobile Filter Button */}
          <div className="md:hidden w-full mb-6">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="w-full flex items-center gap-2">
                  <Filter size={18} /> Filters & Search
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader className="mb-6">
                  <SheetTitle>Filters</SheetTitle>
                </SheetHeader>
                <FilterContent />
              </SheetContent>
            </Sheet>
          </div>

          <div className="flex-grow w-full">
            <div className="mb-6 flex justify-between items-center">
              <h1 className="text-3xl font-heading font-bold text-foreground">Inventory</h1>
              <p className="text-muted-foreground">{filteredVehicles.length} vehicles found</p>
            </div>

            {filteredVehicles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVehicles.map((vehicle) => (
                  <VehicleCard key={vehicle.id} vehicle={vehicle} />
                ))}
              </div>
            ) : (
              <div className="text-center py-20 bg-background rounded-xl border border-border border-dashed">
                <p className="text-muted-foreground text-lg">No vehicles found matching your criteria.</p>
                <Button 
                  variant="link" 
                  className="text-primary mt-2"
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedMake("all");
                    setPriceRange([0, 200000]);
                  }}
                >
                  Clear all filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
