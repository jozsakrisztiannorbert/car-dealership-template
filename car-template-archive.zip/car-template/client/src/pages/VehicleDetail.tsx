import { Navbar, Footer, MobileBottomBar } from "@/components/Layout";
import { mockVehicles, MockVehicle } from "@/lib/mockData";
import { useRoute, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Check, Calendar, Gauge, Fuel, Cog, Info, Phone, Mail, ArrowLeft, MessageSquare } from "lucide-react";
import { dealerConfig } from "@/config/dealer";
import { useToast } from "@/hooks/use-toast";
import NotFound from "./not-found";
import { VehicleCard } from "@/components/VehicleCard";

export default function VehicleDetail() {
  const [match, params] = useRoute("/vehicle/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  if (!match || !params) return <NotFound />;

  const vehicleId = parseInt(params.id);
  const vehicle = mockVehicles.find((v) => v.id === vehicleId);

  if (!vehicle) return <NotFound />;

  // Find similar cars (same make or body type, excluding current)
  const similarVehicles = mockVehicles
    .filter(v => v.id !== vehicleId && (v.make === vehicle.make || v.bodyType === vehicle.bodyType))
    .slice(0, 3);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Inquiry Sent!",
      description: "We'll get back to you shortly.",
    });
  };

  const specs = [
    { label: "Make", value: vehicle.make },
    { label: "Model", value: vehicle.model },
    { label: "Trim", value: vehicle.trim || "-" },
    { label: "Year", value: vehicle.year },
    { label: "Condition", value: "Used" },
    { label: "Mileage", value: `${vehicle.mileage.toLocaleString()} mi` },
    { label: "Fuel Type", value: vehicle.fuel },
    { label: "Transmission", value: vehicle.transmission },
    { label: "Body Type", value: vehicle.bodyType },
    { label: "Engine", value: vehicle.engine || "-" },
    { label: "Power", value: vehicle.power || "-" },
    { label: "Exterior Color", value: vehicle.color || "-" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />

      <main className="flex-grow pt-24 pb-20 container mx-auto px-4">
        
        {/* Breadcrumb / Back */}
        <div className="mb-6">
          <Button variant="ghost" size="sm" className="pl-0 hover:bg-transparent hover:text-primary" onClick={() => setLocation('/inventory')}>
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Inventory
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-24">
          
          {/* Left Column: Images & Details */}
          <div className="lg:col-span-8 space-y-8">
            
            {/* Image Gallery (Simplified for MVP) */}
            <div className="rounded-xl overflow-hidden bg-muted aspect-[16/9] shadow-sm relative group">
              <img 
                src={vehicle.images[0]} 
                alt={`${vehicle.year} ${vehicle.make}`} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute bottom-4 right-4 bg-black/70 text-white px-3 py-1 rounded-full text-xs backdrop-blur-md">
                 1 of {vehicle.images.length} Photos
              </div>
            </div>

            {/* Title & Price (Mobile/Tablet view mostly, but good for header) */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
               <div>
                  <h1 className="text-3xl md:text-4xl font-heading font-bold text-foreground">
                    {vehicle.year} {vehicle.make} {vehicle.model}
                  </h1>
                  <p className="text-lg text-muted-foreground mt-1">{vehicle.trim}</p>
               </div>
               <div className="text-left md:text-right">
                  <h2 className="text-3xl font-heading font-bold text-primary">${vehicle.price.toLocaleString()}</h2>
                  <Badge variant={vehicle.status === 'available' ? 'default' : 'secondary'} className="mt-1">
                    {vehicle.status}
                  </Badge>
               </div>
            </div>
            
            <Separator />

            {/* Quick Highlights */}
             <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 bg-slate-50 rounded-lg border border-border/50 text-center hover:border-primary/20 transition-colors">
                   <Calendar className="mx-auto mb-2 text-primary" size={20} />
                   <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Year</p>
                   <p className="font-medium text-foreground">{vehicle.year}</p>
                </div>
                 <div className="p-4 bg-slate-50 rounded-lg border border-border/50 text-center hover:border-primary/20 transition-colors">
                   <Gauge className="mx-auto mb-2 text-primary" size={20} />
                   <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Mileage</p>
                   <p className="font-medium text-foreground">{vehicle.mileage.toLocaleString()} mi</p>
                </div>
                 <div className="p-4 bg-slate-50 rounded-lg border border-border/50 text-center hover:border-primary/20 transition-colors">
                   <Fuel className="mx-auto mb-2 text-primary" size={20} />
                   <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Fuel</p>
                   <p className="font-medium text-foreground">{vehicle.fuel}</p>
                </div>
                 <div className="p-4 bg-slate-50 rounded-lg border border-border/50 text-center hover:border-primary/20 transition-colors">
                   <Cog className="mx-auto mb-2 text-primary" size={20} />
                   <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Trans</p>
                   <p className="font-medium text-foreground">{vehicle.transmission}</p>
                </div>
             </div>

            {/* Tabs for Info */}
            <Tabs defaultValue="description" className="w-full">
              <TabsList className="w-full justify-start border-b rounded-none p-0 h-auto bg-transparent gap-6">
                <TabsTrigger value="description" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 text-base">Description</TabsTrigger>
                <TabsTrigger value="specs" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 text-base">Specifications</TabsTrigger>
                <TabsTrigger value="features" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent px-0 py-3 text-base">Features</TabsTrigger>
              </TabsList>
              
              <TabsContent value="description" className="pt-6">
                <p className="text-muted-foreground leading-relaxed whitespace-pre-line text-lg">
                  {vehicle.description}
                </p>
              </TabsContent>
              
              <TabsContent value="specs" className="pt-6">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                    {specs.map((spec, i) => (
                      <div key={i} className="flex justify-between py-3 border-b border-border/50 last:border-0 hover:bg-slate-50 px-2 transition-colors">
                        <span className="text-muted-foreground">{spec.label}</span>
                        <span className="font-medium text-foreground">{spec.value}</span>
                      </div>
                    ))}
                 </div>
              </TabsContent>

              <TabsContent value="features" className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {vehicle.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded-lg transition-colors">
                      <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                        <Check size={12} strokeWidth={3} />
                      </div>
                      <span className="text-foreground/90">{feature}</span>
                    </div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Right Column: Contact Form (Sticky) */}
          <div className="lg:col-span-4">
             <div className="sticky top-24 space-y-6">
                <Card className="border-border shadow-md">
                   <CardContent className="p-6">
                      <h3 className="font-heading font-bold text-xl mb-4">Interested in this car?</h3>
                      <p className="text-sm text-muted-foreground mb-6">
                        Fill out the form below or contact us directly. We're here to help.
                      </p>
                      
                      <form onSubmit={handleContactSubmit} className="space-y-4">
                        <div className="space-y-2">
                           <Input placeholder="Full Name" required />
                        </div>
                         <div className="space-y-2">
                           <Input type="email" placeholder="Email Address" required />
                        </div>
                         <div className="space-y-2">
                           <Input type="tel" placeholder="Phone Number" required />
                        </div>
                        <div className="space-y-2">
                          <Textarea 
                            placeholder="Message" 
                            defaultValue={`Hi, I'm interested in the ${vehicle.year} ${vehicle.make} ${vehicle.model}. Is it still available?`}
                            className="min-h-[100px]"
                          />
                        </div>
                        <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
                          Send Message
                        </Button>
                      </form>

                      <div className="mt-6 pt-6 border-t border-border space-y-3">
                         <a href={`tel:${dealerConfig.phone}`} className="flex items-center gap-3 text-sm font-medium hover:text-primary transition-colors">
                            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                                <Phone size={16} />
                            </div>
                            Call {dealerConfig.phone}
                         </a>
                          <a href={`mailto:${dealerConfig.email}`} className="flex items-center gap-3 text-sm font-medium hover:text-primary transition-colors">
                             <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-700">
                                <Mail size={16} />
                            </div>
                            Email Dealer
                         </a>
                         <a href={`https://wa.me/${dealerConfig.whatsapp.replace(/[^0-9]/g, '')}?text=I'm interested in the ${vehicle.year} ${vehicle.make} ${vehicle.model}`} target="_blank" className="flex items-center gap-3 text-sm font-medium hover:text-green-600 transition-colors">
                            <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center text-green-600">
                                <MessageSquare size={16} />
                            </div>
                            WhatsApp Chat
                         </a>
                      </div>
                   </CardContent>
                </Card>
             </div>
          </div>
        </div>

        {/* Similar Cars Section */}
        {similarVehicles.length > 0 && (
          <section className="border-t border-border pt-16">
            <h2 className="text-2xl font-heading font-bold mb-8">You Might Also Like</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarVehicles.map((similarVehicle) => (
                <VehicleCard key={similarVehicle.id} vehicle={similarVehicle} />
              ))}
            </div>
          </section>
        )}
      </main>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
