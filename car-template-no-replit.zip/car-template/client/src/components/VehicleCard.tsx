import { MockVehicle } from "@/lib/mockData";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Fuel, Gauge, Calendar, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface VehicleCardProps {
  vehicle: MockVehicle;
  className?: string;
}

export function VehicleCard({ vehicle, className }: VehicleCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'default'; // primary color
      case 'reserved': return 'secondary'; // yellow-ish usually, but secondary is fine
      case 'sold': return 'destructive'; // red
      default: return 'outline';
    }
  };

  return (
    <Link href={`/vehicle/${vehicle.id}`}>
      <a className={cn("block group h-full", className)}>
        <Card className="h-full overflow-hidden border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg bg-card flex flex-col">
          <div className="relative aspect-[16/10] overflow-hidden bg-muted">
            <img
              src={vehicle.images[0]}
              alt={`${vehicle.year} ${vehicle.make} ${vehicle.model}`}
              className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute top-3 right-3">
              <Badge variant={getStatusColor(vehicle.status)} className="uppercase tracking-wider font-bold text-[10px]">
                {vehicle.status}
              </Badge>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
               <span className="text-white font-medium flex items-center gap-2">View Details <ArrowRight size={16} /></span>
            </div>
          </div>
          
          <CardHeader className="p-5 pb-2">
            <div className="flex justify-between items-start gap-2">
              <div>
                <h3 className="font-heading font-bold text-lg leading-tight text-foreground line-clamp-1">
                  {vehicle.make} {vehicle.model}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">{vehicle.trim}</p>
              </div>
              <p className="font-heading font-bold text-lg text-primary">
                ${vehicle.price.toLocaleString()}
              </p>
            </div>
          </CardHeader>

          <CardContent className="p-5 pt-4 mt-auto">
            <div className="grid grid-cols-2 gap-y-3 gap-x-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar size={14} className="text-primary/70" />
                <span>{vehicle.year}</span>
              </div>
              <div className="flex items-center gap-2">
                <Gauge size={14} className="text-primary/70" />
                <span>{vehicle.mileage.toLocaleString()} mi</span>
              </div>
               <div className="flex items-center gap-2">
                <Fuel size={14} className="text-primary/70" />
                <span>{vehicle.fuel}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3.5 h-3.5 rounded-full border border-border" style={{ backgroundColor: vehicle.color === 'White' ? '#fff' : vehicle.color === 'Black' ? '#000' : 'gray' }}></span>
                <span className="truncate">{vehicle.color}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </a>
    </Link>
  );
}
