import { type Vehicle } from "@shared/schema";

// Mock data types matching the schema conceptually
export interface MockVehicle {
  id: number;
  make: string;
  model: string;
  trim?: string;
  year: number;
  price: number;
  mileage: number;
  fuel: string;
  transmission: string;
  bodyType: string;
  engine?: string;
  power?: string;
  color?: string;
  description: string;
  features: string[];
  images: string[];
  status: "available" | "reserved" | "sold";
  createdAt: string;
}

export const mockVehicles: MockVehicle[] = [
  {
    id: 1,
    make: "Porsche",
    model: "911",
    trim: "Carrera S",
    year: 2023,
    price: 135000,
    mileage: 4500,
    fuel: "Petrol",
    transmission: "Automatic",
    bodyType: "Coupe",
    engine: "3.0L Twin-Turbo Flat-6",
    power: "443 hp",
    color: "Guards Red",
    description: "Immaculate condition 911 Carrera S with Sport Chrono package. One owner, low miles, garage kept.",
    features: ["Sport Chrono Package", "Leather Interior", "BOSE Surround Sound", "Sunroof", "Heated Seats", "Navigation"],
    images: ["/images/car-red.png"],
    status: "available",
    createdAt: "2024-02-15T10:00:00Z",
  },
  {
    id: 2,
    make: "Mercedes-Benz",
    model: "GLE",
    trim: "450 4MATIC",
    year: 2024,
    price: 72000,
    mileage: 1200,
    fuel: "Hybrid",
    transmission: "Automatic",
    bodyType: "SUV",
    engine: "3.0L Inline-6 Turbo",
    power: "362 hp",
    color: "Polar White",
    description: "Luxury SUV with spacious interior and advanced safety features. Perfect for families.",
    features: ["MBUX Infotainment", "Panoramic Roof", "Driver Assistance Package", "3rd Row Seating", "Burmester Audio"],
    images: ["/images/car-white-suv.png"],
    status: "available",
    createdAt: "2024-02-18T14:30:00Z",
  },
  {
    id: 3,
    make: "BMW",
    model: "5 Series",
    trim: "530i xDrive",
    year: 2022,
    price: 48500,
    mileage: 28000,
    fuel: "Petrol",
    transmission: "Automatic",
    bodyType: "Sedan",
    engine: "2.0L TwinPower Turbo",
    power: "248 hp",
    color: "Phytonic Blue Metallic",
    description: "Certified Pre-Owned BMW 5 Series. Excellent commuter car with premium comfort.",
    features: ["Head-Up Display", "Wireless Charging", "Gesture Control", "Heated Steering Wheel", "Parking Assistant"],
    images: ["/images/car-blue-sedan.png"],
    status: "reserved",
    createdAt: "2024-01-20T09:15:00Z",
  },
    {
    id: 4,
    make: "Audi",
    model: "RS 5",
    trim: "Sportback",
    year: 2023,
    price: 89000,
    mileage: 8500,
    fuel: "Petrol",
    transmission: "Automatic",
    bodyType: "Coupe",
    engine: "2.9L TFSI V6",
    power: "444 hp",
    color: "Nardo Gray",
    description: "High performance sportback with aggressive styling and Quattro all-wheel drive.",
    features: ["Carbon Fiber Package", "RS Sport Exhaust", "Bang & Olufsen Sound", "Virtual Cockpit", "Black Optic Package"],
    images: ["/images/car-red.png"], // Placeholder reuse
    status: "available",
    createdAt: "2024-02-10T11:20:00Z",
  },
];
