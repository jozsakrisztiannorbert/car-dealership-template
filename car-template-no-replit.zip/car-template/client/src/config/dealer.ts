export const dealerConfig = {
  dealerName: "Prestige Auto Haus",
  logoUrl: "/favicon.png", // Using favicon as placeholder for now
  primaryColor: "hsl(215 100% 15%)",
  accentColor: "hsl(350 80% 50%)",
  city: "Beverly Hills",
  address: "123 Luxury Lane, Beverly Hills, CA 90210",
  phone: "+1 (555) 123-4567",
  whatsapp: "+1 (555) 987-6543",
  email: "sales@prestigeautohaus.com",
  hours: {
    mon_fri: "9:00 AM - 7:00 PM",
    sat: "10:00 AM - 5:00 PM",
    sun: "Closed",
  },
  socialLinks: {
    facebook: "https://facebook.com",
    instagram: "https://instagram.com",
    twitter: "https://twitter.com",
  },
  googleReviewUrl: "https://g.page/r/placeholder",
  defaultSeoTitle: "Prestige Auto Haus | Luxury Vehicles",
  defaultSeoDescription: "Premium pre-owned luxury vehicles in Beverly Hills. BMW, Mercedes, Audi, and more.",
  languagesEnabled: ["en", "es"],
};
