import { Navbar, Footer, MobileBottomBar } from "@/components/Layout";
import { dealerConfig } from "@/config/dealer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, Mail, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Message Sent",
      description: "We'll get back to you as soon as possible.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />

      <main className="flex-grow pt-24 pb-20 container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-heading font-bold text-foreground mb-4">Contact Us</h1>
          <p className="text-muted-foreground text-lg">We'd love to hear from you. Get in touch with us today.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          
          <div className="space-y-8">
            <Card className="border-border shadow-sm">
              <CardContent className="p-8 space-y-6">
                 <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <Phone size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Phone</h3>
                      <p className="text-muted-foreground mb-1">Call us for immediate assistance.</p>
                      <a href={`tel:${dealerConfig.phone}`} className="text-primary font-semibold hover:underline">{dealerConfig.phone}</a>
                    </div>
                 </div>

                 <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <Mail size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Email</h3>
                      <p className="text-muted-foreground mb-1">Send us an email anytime.</p>
                      <a href={`mailto:${dealerConfig.email}`} className="text-primary font-semibold hover:underline">{dealerConfig.email}</a>
                    </div>
                 </div>

                 <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1">Location</h3>
                      <p className="text-muted-foreground mb-1">{dealerConfig.address}</p>
                      <a href="#" className="text-primary font-semibold hover:underline">Get Directions</a>
                    </div>
                 </div>
              </CardContent>
            </Card>

            <div className="h-64 bg-slate-200 rounded-xl overflow-hidden border border-border">
               {/* Map Placeholder */}
               <div className="w-full h-full flex items-center justify-center text-slate-500">
                  Google Maps Embed
               </div>
            </div>
          </div>

          <Card className="border-border shadow-sm">
            <CardHeader className="p-8 pb-4">
              <CardTitle className="text-2xl font-heading">Send a Message</CardTitle>
            </CardHeader>
            <CardContent className="p-8 pt-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Input placeholder="First Name" required />
                  </div>
                  <div className="space-y-2">
                    <Input placeholder="Last Name" required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Input type="email" placeholder="Email Address" required />
                </div>
                <div className="space-y-2">
                  <Input type="tel" placeholder="Phone Number" />
                </div>
                <div className="space-y-2">
                  <Textarea placeholder="How can we help you?" className="min-h-[150px]" required />
                </div>
                <Button type="submit" className="w-full bg-primary hover:bg-primary/90">Send Message</Button>
              </form>
            </CardContent>
          </Card>

        </div>
      </main>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
