import { Navbar, Footer, MobileBottomBar } from "@/components/Layout";
import { dealerConfig } from "@/config/dealer";
import { mockVehicles } from "@/lib/mockData";
import { VehicleCard } from "@/components/VehicleCard";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Star, ShieldCheck, Clock } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const featuredVehicles = mockVehicles.slice(0, 3);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[90vh] min-h-[600px] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
             <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 to-slate-900/40 z-10" />
             <img 
                src="/images/hero-bg.png" 
                alt="Showroom" 
                className="w-full h-full object-cover"
             />
          </div>

          <div className="container relative z-20 px-4 pt-20">
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="max-w-3xl"
            >
              <h1 className="text-5xl md:text-7xl font-heading font-extrabold text-white leading-tight mb-6">
                Elevate Your <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">Drive Today.</span>
              </h1>
              <p className="text-xl text-slate-300 mb-8 max-w-xl leading-relaxed">
                Discover our curated collection of premium pre-owned luxury vehicles. 
                Quality inspected, certified, and ready for the road.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/inventory">
                  <Button size="lg" className="bg-primary hover:bg-primary/90 text-white h-14 px-8 text-lg rounded-full">
                    View Inventory <ArrowRight className="ml-2" size={20} />
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline" className="border-white/20 bg-white/10 backdrop-blur-sm text-white hover:bg-white hover:text-slate-900 h-14 px-8 text-lg rounded-full">
                    Contact Us
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Featured Inventory */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-end mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-heading font-bold mb-3 text-foreground">Featured Arrivals</h2>
                <p className="text-muted-foreground">Hand-picked luxury vehicles just for you.</p>
              </div>
              <Link href="/inventory">
                <Button variant="ghost" className="text-primary hover:text-primary/80 hidden sm:flex">
                  View All <ArrowRight className="ml-2" size={16} />
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredVehicles.map((vehicle, index) => (
                <motion.div
                  key={vehicle.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <VehicleCard vehicle={vehicle} />
                </motion.div>
              ))}
            </div>

             <div className="mt-12 text-center sm:hidden">
              <Link href="/inventory">
                <Button variant="outline" className="w-full">
                  View All Inventory
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Trust/Services */}
        <section className="py-24 bg-slate-50 border-y border-border">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl font-heading font-bold mb-4 text-foreground">Why Choose {dealerConfig.dealerName}?</h2>
              <p className="text-muted-foreground">We don't just sell cars; we build relationships founded on trust, transparency, and quality.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="text-center p-6 rounded-2xl bg-background border border-border/50 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 text-primary">
                  <ShieldCheck size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3 font-heading">Certified Quality</h3>
                <p className="text-muted-foreground leading-relaxed">Every vehicle undergoes a rigorous 150-point inspection to ensure it meets our high standards.</p>
              </div>

              <div className="text-center p-6 rounded-2xl bg-background border border-border/50 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 text-primary">
                  <Star size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3 font-heading">Fair Pricing</h3>
                <p className="text-muted-foreground leading-relaxed">Transparent, market-based pricing with no hidden fees or surprises. What you see is what you pay.</p>
              </div>

               <div className="text-center p-6 rounded-2xl bg-background border border-border/50 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6 text-primary">
                  <Clock size={32} />
                </div>
                <h3 className="text-xl font-bold mb-3 font-heading">Fast Financing</h3>
                <p className="text-muted-foreground leading-relaxed">Competitive financing options approved in minutes, not hours. Drive away today.</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-24 bg-primary text-primary-foreground relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none">
                <div className="absolute -top-24 -right-24 w-96 h-96 bg-white rounded-full blur-3xl" />
                <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-white rounded-full blur-3xl" />
            </div>
            
            <div className="container mx-auto px-4 relative z-10 text-center">
                <h2 className="text-3xl md:text-5xl font-heading font-bold mb-6">Ready to find your dream car?</h2>
                <p className="text-primary-foreground/80 text-lg mb-10 max-w-2xl mx-auto">
                    Browse our extensive inventory online or visit our showroom in {dealerConfig.city} for a test drive.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                     <Link href="/inventory">
                        <Button size="lg" variant="secondary" className="h-14 px-8 text-lg rounded-full text-primary font-bold">
                            View Inventory
                        </Button>
                    </Link>
                    <a href={`tel:${dealerConfig.phone}`}>
                        <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground hover:text-primary h-14 px-8 text-lg rounded-full bg-transparent">
                            Call {dealerConfig.phone}
                        </Button>
                    </a>
                </div>
            </div>
        </section>
      </main>

      <Footer />
      <MobileBottomBar />
    </div>
  );
}
